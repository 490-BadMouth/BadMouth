import numpy as np

from keras import models

from recorder import record_audio, terminate
from spec import preprocessing_Audio


loaded_model = models.load_model("bad_mouth_1c_16n_0d.model")

def predict_mic():
    # audio,rate = record_audio()
    # spec = preprocessing_Audio(audio,rate)
    
    audio,rate= record_audio()
    
    spec= preprocessing_Audio(audio,rate)
    
    prediction = loaded_model(spec)
    
    print(prediction)
    
    if (prediction > 0.5):
        print("Bad Word")
    
    else:
        print('good word')
    
    # prediction = [1 if prediction > 0.99 else 0 for prediction in prediction]

    return prediction




if __name__ == "__main__":
    # while True:
    predict_mic()
    terminate()
    