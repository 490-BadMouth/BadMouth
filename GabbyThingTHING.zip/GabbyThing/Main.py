import numpy as np
import wave 
from keras import models
from matplotlib import pyplot as plt
from recorder import record_audio, terminate,combineframes
from spec import preprocess
import tensorflow as tf 
import pandas as pd 
import torch
import os


model = models.load_model("bad_mouth_2c_16n_0d_dropout_LN_7e_44k.model") 



import time
def predict_mic():   
    
    spec = record_audio()

    spec= preprocess(spec) # input: waveform and sample rate spec
  
    prediction = model.predict(spec)
    print(prediction)
    
    
    if (prediction > 0.60):
        print("Bad Word")
    
    else:
        print('good word')
    
    # prediction = [1 if prediction > 0.99 else 0 for prediction in prediction]
    

    return prediction





if __name__ == "__main__":
    predict_mic()  
    terminate() 

        
    